%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Copyright 2000-2002 
%
% Michail G. Lagoudakis (mgl@cs.duke.edu)
% Ronald Parr (parr@cs.duke.edu)
%
% Department of Computer Science
% Box 90129
% Duke University
% Durham, NC 27708
% 
%
% phi = pendulum_basis_rbf_C(state, action)
%
% Computes RBF basis functions for the pendulum domain. The RBFs are
% arranged in a nrbfx x nrbfy grid with their means equally spaced
% over angle [-pi/4:pi/4] and angular velocity [-1:1] and sigma^2 =
% 1. In addition, there is also a constant basis function. The set is
% duplicated for each action. The "action" determines which segment
% will be active.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
